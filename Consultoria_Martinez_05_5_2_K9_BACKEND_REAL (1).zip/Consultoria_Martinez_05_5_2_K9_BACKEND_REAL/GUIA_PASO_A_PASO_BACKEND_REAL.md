# GUÍA PASO A PASO — Backend real (K.9 + base de datos + acceso admin)

Esta guía no requiere que sepas programar. Solo tienes que seguir los pasos
en orden, tal como cuando actualizas tu repositorio de GitHub.

Al terminar, tu panel de administración (`/admin/`) va a guardar los
documentos en una base de datos real en internet (no en tu navegador como
antes), y solo tú vas a poder entrar con tu correo y contraseña.

---

## PASO 1 — Crear tu cuenta y proyecto en Supabase

Supabase es el servicio (gratuito para este tamaño de proyecto) que va a
guardar tu base de datos, tus archivos y el acceso con contraseña.

1. Entra a **https://supabase.com** y crea una cuenta (puedes usar tu cuenta
   de GitHub para entrar más rápido).
2. Haz clic en **"New project"**.
3. Ponle un nombre, por ejemplo `consultoria-martinez`.
4. Crea una contraseña para la base de datos y **guárdala en un lugar seguro**
   (no la vuelves a necesitar en el día a día, pero consérvala).
5. Elige la región más cercana a tus usuarios (por ejemplo, una región de
   Sudamérica si tus clientes están ahí).
6. Espera 1-2 minutos mientras Supabase prepara el proyecto.

## PASO 2 — Crear las tablas (ejecutar el script)

1. Dentro de tu proyecto de Supabase, en el menú de la izquierda, entra a
   **"SQL Editor"**.
2. Haz clic en **"New query"**.
3. Abre el archivo `supabase/esquema.sql` que viene en este mismo ZIP,
   copia **todo** su contenido y pégalo en el cuadro del SQL Editor.
4. Haz clic en **"RUN"** (o presiona Ctrl+Enter).
5. Debe aparecer un mensaje de éxito (algo como "Success. No rows returned").
   Si aparece un error, no continúes: copia el mensaje de error y compártemelo.

Esto crea automáticamente:
- La tabla donde se guardan los documentos.
- La tabla de auditoría (historial de cambios).
- Las reglas de seguridad que hacen cumplir que "una entrada no es lo mismo
  que una publicación, ni lo mismo que un conocimiento autorizado para
  Martínez".
- El espacio de almacenamiento privado para los archivos que subas
  (PDF, DOCX, XLSX, etc.).

## PASO 3 — Crear tu usuario administrador

1. En el menú de la izquierda, entra a **"Authentication"** → pestaña **"Users"**.
2. Haz clic en **"Add user"** → **"Create new user"**.
3. Escribe tu correo y una contraseña (esta sí la usarás cada vez que
   entres al panel).
4. Marca la opción de **"Auto Confirm User"** si aparece, para no tener que
   confirmar por correo.
5. Guarda.

Este correo y contraseña son los que vas a usar para entrar a `/admin/`.

## PASO 4 — Copiar tus claves de conexión

1. En el menú de la izquierda, entra a **"Project Settings"** → **"API"**.
2. Vas a ver dos valores que necesitas copiar:
   - **Project URL**
   - **anon public** (una clave larga de letras y números)
3. Abre el archivo `js/supabase-config.js` de este ZIP con cualquier editor
   de texto simple (incluso el Bloc de notas sirve).
4. Reemplaza:
   - `PEGA_AQUI_TU_PROJECT_URL` por tu Project URL.
   - `PEGA_AQUI_TU_ANON_KEY` por tu clave anon public.
5. Guarda el archivo.

> Nota de seguridad: estos dos valores no son secretos peligrosos — están
> protegidos por las reglas que creamos en el Paso 2. Es normal que se vean
> en el código del sitio público.

## PASO 5 — Subir todo a tu repositorio de GitHub

1. Sube **todo** el contenido de este ZIP a tu repositorio, igual que en
   las entregas anteriores (respetando las carpetas `admin/`, `js/`,
   `images/`, `supabase/`, `docs/`).
2. Espera a que tu sitio se actualice (GitHub Pages tarda uno o dos minutos).

## PASO 6 — Probar

1. Abre tu sitio publicado y entra a `/admin/`.
2. Debe pedirte correo y contraseña — usa los del Paso 3.
3. Registra un documento de prueba (con o sin archivo adjunto).
4. Debe aparecer en la bandeja con estado `inbox`.
5. Prueba el flujo completo: Clasificar → Revisión → Aprobar → Autorizar
   asistente / Autorizar recursos → Publicar.
6. Cierra sesión y vuelve a entrar: los documentos deben seguir ahí (a
   diferencia de antes, esto ya no depende de tu navegador).
7. Abre el panel desde otra computadora o celular con tu mismo usuario:
   debe verse la misma información.

---

## Qué cambia respecto a la versión anterior

- Antes: los documentos se guardaban en tu navegador (`localStorage`) y se
  perdían al cambiar de dispositivo o borrar el caché.
- Ahora: se guardan en una base de datos real, con copia de seguridad,
  accesible desde cualquier lugar con tu usuario.
- Antes: cualquiera que abriera `/admin/` podía usarlo.
- Ahora: se requiere iniciar sesión con tu correo y contraseña.
- Se mantiene intacta la regla: **Entrada ≠ publicación ≠ conocimiento
  autorizado** — y ahora la hace cumplir la propia base de datos, no solo
  el diseño de la pantalla.

## Qué falta todavía (próximas entregas, en tu mismo orden)

5. API segura dedicada (hoy el panel habla directo con la base de datos,
   protegida por las reglas del Paso 2; más adelante añadimos funciones
   propias para lógica más avanzada de clasificación).
6. Procesamiento automático de PDF/DOCX/XLSX (hoy quedan registrados y
   marcados como "pendiente de procesador").
7. Página pública "Centro de Información" que muestre los documentos
   publicados.
8. Conexión real entre "autorizado para Martínez" y las respuestas del
   asistente.
9. K.10 — Red Team.
10. Integraciones futuras (WhatsApp, voz).

Cuando termines el Paso 6 y todo funcione, dime "listo" y seguimos con el
punto 5 de tu lista.
